package bg.softuni.springdataintroexercise.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
