package bg.softuni.springdataintroexercise.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
